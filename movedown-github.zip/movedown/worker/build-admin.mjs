// Re-generates src/admin.js from admin.src.html (run after editing the admin page)
import fs from 'node:fs';
const html = fs.readFileSync(new URL('./admin.src.html', import.meta.url), 'utf8');
fs.writeFileSync(
  new URL('./src/admin.js', import.meta.url),
  '// Generated from admin.src.html – edit that file, then run: node build-admin.mjs\nexport const ADMIN_HTML = ' + JSON.stringify(html) + ';\n',
);
