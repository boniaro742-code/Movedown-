import { ADMIN_HTML } from './admin.js';

const PACKAGE_RE = /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/;
const NAME_RE = /^[\w.-]+$/;
const CATALOG_KEY = 'catalog/apps.json';

const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'access-control-allow-headers': 'content-type, x-admin-password, x-filename, range',
};

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', ...CORS },
  });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* ---------- catalog (a single JSON file in R2) ---------- */

async function loadApps(env) {
  const obj = await env.BUCKET.get(CATALOG_KEY);
  if (!obj) return [];
  try {
    return await obj.json();
  } catch {
    return [];
  }
}

const saveApps = (env, apps) =>
  env.BUCKET.put(CATALOG_KEY, JSON.stringify(apps), {
    httpMetadata: { contentType: 'application/json' },
  });

const toPublic = (a) => ({
  id: a.id,
  name: a.name,
  packageName: a.packageName,
  versionName: a.versionName,
  versionCode: a.versionCode,
  description: a.description,
  sizeBytes: a.sizeBytes,
  downloads: a.downloads,
  iconPath: a.icon ? `/files/icons/${a.icon}` : null,
  downloadPath: `/api/apps/${a.id}/download`,
  updatedAt: a.updatedAt,
});

/* ---------- admin auth (ONLY for uploading; downloads need no key) ---------- */

async function requireAdmin(request, env) {
  if (!env.ADMIN_PASSWORD) {
    return json({ error: 'Admin disabled. Run: npx wrangler secret put ADMIN_PASSWORD' }, 503);
  }
  const enc = new TextEncoder();
  const [given, real] = await Promise.all([
    crypto.subtle.digest('SHA-256', enc.encode(request.headers.get('x-admin-password') || '')),
    crypto.subtle.digest('SHA-256', enc.encode(env.ADMIN_PASSWORD)),
  ]);
  if (!crypto.subtle.timingSafeEqual(given, real)) {
    await sleep(800); // slows down password guessing
    return json({ error: 'Wrong password' }, 401);
  }
  return null;
}

/* ---------- public file serving ---------- */

function objectResponse(request, obj, extraHeaders = {}) {
  const headers = new Headers(extraHeaders);
  obj.writeHttpMetadata(headers);
  headers.set('etag', obj.httpEtag);
  headers.set('accept-ranges', 'bytes');
  for (const [k, v] of Object.entries(CORS)) headers.set(k, v);

  let status = 200;
  let length = obj.size;
  if (request.headers.get('range') && obj.range) {
    let offset;
    if ('suffix' in obj.range) {
      length = Math.min(obj.range.suffix, obj.size);
      offset = obj.size - length;
    } else {
      offset = obj.range.offset ?? 0;
      length = obj.range.length ?? obj.size - offset;
    }
    headers.set('content-range', `bytes ${offset}-${offset + length - 1}/${obj.size}`);
    status = 206;
  }
  headers.set('content-length', String(length));
  return new Response(request.method === 'HEAD' ? null : obj.body, { status, headers });
}

/* ---------- main router ---------- */

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });

    try {
      /* ----- public ----- */
      if (method === 'GET' && path === '/') {
        return json({ name: 'MoveDown', apps: (await loadApps(env)).length });
      }
      if (method === 'GET' && path === '/health') return json({ ok: true });

      if (method === 'GET' && path === '/api/apps') {
        const q = (url.searchParams.get('q') || '').toLowerCase().trim();
        let items = await loadApps(env);
        if (q) {
          items = items.filter(
            (a) => a.name.toLowerCase().includes(q) || (a.description || '').toLowerCase().includes(q),
          );
        }
        return json([...items].sort((a, b) => b.updatedAt - a.updatedAt).map(toPublic));
      }

      let m = path.match(/^\/api\/apps\/([\w-]+)$/);
      if (method === 'GET' && m) {
        const a = (await loadApps(env)).find((x) => x.id === m[1]);
        return a ? json(toPublic(a)) : json({ error: 'Not found' }, 404);
      }

      m = path.match(/^\/api\/apps\/([\w-]+)\/download$/);
      if ((method === 'GET' || method === 'HEAD') && m) {
        const apps = await loadApps(env);
        const a = apps.find((x) => x.id === m[1]);
        if (!a) return json({ error: 'Not found' }, 404);
        const obj = await env.BUCKET.get(`apk/${a.apk}`, { range: request.headers });
        if (!obj) return json({ error: 'APK file missing' }, 404);
        if (method === 'GET' && !request.headers.get('range')) {
          ctx.waitUntil(
            (async () => {
              const fresh = await loadApps(env);
              const t = fresh.find((x) => x.id === a.id);
              if (t) {
                t.downloads = (t.downloads || 0) + 1;
                await saveApps(env, fresh);
              }
            })().catch(() => {}),
          );
        }
        const safe = a.name.replace(/[^\w.-]+/g, '_');
        return objectResponse(request, obj, {
          'content-type': 'application/vnd.android.package-archive',
          'content-disposition': `attachment; filename="${safe}-${a.versionName}.apk"`,
        });
      }

      m = path.match(/^\/files\/icons\/([\w.-]+)$/);
      if (method === 'GET' && m) {
        const obj = await env.BUCKET.get(`icons/${m[1]}`);
        if (!obj) return new Response('Not found', { status: 404 });
        return objectResponse(request, obj, { 'cache-control': 'public, max-age=604800' });
      }

      /* ----- admin page ----- */
      if (method === 'GET' && path === '/admin') {
        return new Response(ADMIN_HTML, { headers: { 'content-type': 'text/html; charset=utf-8' } });
      }

      /* ----- admin API ----- */
      if (path.startsWith('/api/admin/')) {
        const denied = await requireAdmin(request, env);
        if (denied) return denied;

        // Step 1: upload a raw file (apk or icon) straight into R2
        m = path.match(/^\/api\/admin\/files\/(apk|icon)$/);
        if (method === 'PUT' && m) {
          const kind = m[1];
          const filename = decodeURIComponent(request.headers.get('x-filename') || '');
          const ext = (filename.match(/\.([A-Za-z0-9]+)$/)?.[1] || '').toLowerCase();
          if (kind === 'apk' && ext !== 'apk') return json({ error: 'APK file must end with .apk' }, 400);
          if (kind === 'icon' && !['png', 'jpg', 'jpeg', 'webp'].includes(ext)) {
            return json({ error: 'Icon must be png, jpg or webp' }, 400);
          }
          const size = Number(request.headers.get('content-length') || 0);
          const maxMb = Number(env.MAX_APK_MB || 100);
          if (!size) return json({ error: 'Missing file' }, 400);
          if (size > maxMb * 1024 * 1024) return json({ error: `File is larger than ${maxMb} MB` }, 413);

          const key = crypto.randomUUID() + '.' + (kind === 'apk' ? 'apk' : ext);
          await env.BUCKET.put(`${kind === 'apk' ? 'apk' : 'icons'}/${key}`, request.body, {
            httpMetadata: {
              contentType: kind === 'apk' ? 'application/vnd.android.package-archive' : `image/${ext === 'jpg' ? 'jpeg' : ext}`,
            },
          });
          return json({ key, size }, 201);
        }

        // Step 2: create an app entry
        if (method === 'POST' && path === '/api/admin/apps') {
          const b = await request.json().catch(() => ({}));
          if (
            !b.name || !b.versionName || !PACKAGE_RE.test(b.packageName || '') ||
            !Number.isInteger(Number(b.versionCode)) || !NAME_RE.test(b.apkKey || '')
          ) {
            return json({ error: 'Need: name, valid packageName, versionName, versionCode (integer) and apk file' }, 400);
          }
          const apkHead = await env.BUCKET.head(`apk/${b.apkKey}`);
          if (!apkHead) return json({ error: 'APK was not uploaded' }, 400);
          const apps = await loadApps(env);
          if (apps.some((a) => a.packageName === b.packageName)) {
            return json({ error: 'This packageName already exists – update it instead' }, 409);
          }
          const now = Date.now();
          const created = {
            id: crypto.randomUUID(),
            name: b.name,
            packageName: b.packageName,
            versionName: b.versionName,
            versionCode: Number(b.versionCode),
            description: b.description || '',
            apk: b.apkKey,
            icon: NAME_RE.test(b.iconKey || '') ? b.iconKey : null,
            sizeBytes: apkHead.size,
            downloads: 0,
            createdAt: now,
            updatedAt: now,
          };
          apps.push(created);
          await saveApps(env, apps);
          return json(toPublic(created), 201);
        }

        m = path.match(/^\/api\/admin\/apps\/([\w-]+)$/);

        // Update an existing app
        if (method === 'PUT' && m) {
          const apps = await loadApps(env);
          const a = apps.find((x) => x.id === m[1]);
          if (!a) return json({ error: 'Not found' }, 404);
          const b = await request.json().catch(() => ({}));
          for (const k of ['name', 'description', 'versionName']) if (b[k]) a[k] = b[k];
          if (b.versionCode) {
            if (!Number.isInteger(Number(b.versionCode))) return json({ error: 'versionCode must be an integer' }, 400);
            a.versionCode = Number(b.versionCode);
          }
          const old = [];
          if (b.apkKey && NAME_RE.test(b.apkKey)) {
            const head = await env.BUCKET.head(`apk/${b.apkKey}`);
            if (!head) return json({ error: 'APK was not uploaded' }, 400);
            old.push(`apk/${a.apk}`);
            a.apk = b.apkKey;
            a.sizeBytes = head.size;
          }
          if (b.iconKey && NAME_RE.test(b.iconKey)) {
            if (a.icon) old.push(`icons/${a.icon}`);
            a.icon = b.iconKey;
          }
          a.updatedAt = Date.now();
          await saveApps(env, apps);
          if (old.length) await env.BUCKET.delete(old);
          return json(toPublic(a));
        }

        // Delete an app
        if (method === 'DELETE' && m) {
          const apps = await loadApps(env);
          const i = apps.findIndex((x) => x.id === m[1]);
          if (i < 0) return json({ error: 'Not found' }, 404);
          const [removed] = apps.splice(i, 1);
          await saveApps(env, apps);
          const files = [`apk/${removed.apk}`];
          if (removed.icon) files.push(`icons/${removed.icon}`);
          await env.BUCKET.delete(files);
          return json({ ok: true });
        }
      }

      return json({ error: 'Not found' }, 404);
    } catch (err) {
      console.error(err);
      return json({ error: 'Server error' }, 500);
    }
  },
};
