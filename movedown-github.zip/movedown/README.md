# MoveDown

Free, Play Store–style app store for **your own apps only**.
Anyone can browse and download your apps – **no API key, no login**. Only you can upload (admin password).

**No server to rent:** the backend is a Cloudflare Worker + R2 bucket (free tier is enough to start).
**No R2 key inside the app or the code:** the Worker is bound to the bucket directly.

```
movedown/
├── worker/     Cloudflare Worker – catalog API, APK storage in R2, admin page (/admin)
└── android/    Kotlin + Jetpack Compose app (the store itself)
```

## 1) Deploy the backend (one time)
```bash
cd worker
npm install
npx wrangler login                          # opens browser, log in to Cloudflare
npx wrangler r2 bucket create movedown      # the bucket that stores APKs + icons
npx wrangler secret put ADMIN_PASSWORD      # type a LONG random password (only you know it)
npx wrangler deploy                         # prints https://movedown.<your-name>.workers.dev
```
- Open `https://movedown.<your-name>.workers.dev/admin`, enter the password, upload your APK (+ icon, name, package name, version name, version code).
- Update an app: upload again with the **same package name** and a **higher version code**.
- Max file size is 100 MB per file on the Cloudflare Free/Pro plan (`MAX_APK_MB` in `wrangler.toml`).
- Local test: copy `.dev.vars.example` to `.dev.vars`, then `npx wrangler dev`.

## 2) Android app
1. Open `android/` in Android Studio.
2. In `app/build.gradle.kts` set `BASE_URL` to your Worker URL (keep the trailing `/`).
3. Run on your phone, or Build > Generate Signed App Bundle / APK.
4. Share the MoveDown APK. On first install people must allow "Install unknown apps" for MoveDown.

## 3) Build the APK on GitHub (no Android Studio needed)
1. Create a GitHub repo and upload the **contents** of this folder (so `.github/`, `android/`, `worker/` are at the repo root).
2. Repo > Settings > Secrets and variables > Actions > **Variables** > New variable:
   `BASE_URL` = `https://movedown.<your-name>.workers.dev/`
3. (Recommended) Create your signing key once, on your PC/Termux, and **keep the file safe forever** (updates must use the same key):
   ```bash
   keytool -genkeypair -v -keystore release.keystore -alias movedown -keyalg RSA -keysize 2048 -validity 36500
   base64 -w0 release.keystore      # copy this output
   ```
   Repo > Settings > Secrets and variables > Actions > **Secrets**, add:
   `KEYSTORE_BASE64` (the base64 text), `KEYSTORE_PASSWORD`, `KEY_ALIAS` (movedown), `KEY_PASSWORD`.
   Without these secrets the workflow builds a *debug* APK (works, but not for the final release).
4. Push to `main` (or Actions tab > "Build Android APK" > Run workflow). After ~5 minutes, open the finished run and download **MoveDown-apk** from *Artifacts*.
5. Want a public download link? Push a tag: `git tag v1.0.0 && git push --tags` – the APK is attached to a GitHub Release.

Every build uses `VERSION_CODE = run number`, so each new build is an update for people who already installed it.
Never commit your `.keystore` file or passwords (they are in `.gitignore`).

## Security notes
- NEVER put an R2 Access Key / Secret / API token in the Android app or in this repo. They are not needed.
- Only the upload API is protected (`x-admin-password`). Downloads are open to everyone.
- Your apps must be signed; updates must use the same signing key as the installed version.
