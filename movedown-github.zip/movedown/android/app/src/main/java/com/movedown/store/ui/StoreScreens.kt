package com.movedown.store.ui

import android.text.format.Formatter
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.movedown.store.StoreViewModel
import com.movedown.store.UiState
import com.movedown.store.data.StoreApp
import com.movedown.store.install.Installer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreRoot(vm: StoreViewModel) {
    var selectedId by rememberSaveable { mutableStateOf<String?>(null) }
    val snackbar = remember { SnackbarHostState() }

    LaunchedEffect(vm.message) {
        vm.message?.let {
            snackbar.showSnackbar(it)
            vm.message = null
        }
    }

    val selected = (vm.state as? UiState.Ready)?.apps?.firstOrNull { it.id == selectedId }
    BackHandler(enabled = selected != null) { selectedId = null }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text(selected?.name ?: "MoveDown") },
                navigationIcon = {
                    if (selected != null) TextButton(onClick = { selectedId = null }) { Text("←") }
                },
                actions = {
                    if (selected == null) TextButton(onClick = { vm.load() }) { Text("Refresh") }
                },
            )
        },
    ) { padding ->
        Box(Modifier.padding(padding).fillMaxSize()) {
            if (selected != null) {
                DetailScreen(selected, vm)
            } else {
                HomeScreen(vm, onOpen = { selectedId = it.id })
            }
        }
    }
}

@Composable
fun HomeScreen(vm: StoreViewModel, onOpen: (StoreApp) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = vm::onQueryChange,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Search apps") },
            singleLine = true,
        )
        when (val s = vm.state) {
            UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            is UiState.Error -> Column(
                Modifier.fillMaxSize().padding(24.dp),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(s.message)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { vm.load() }) { Text("Retry") }
            }
            is UiState.Ready -> if (s.apps.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("No apps yet") }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(s.apps, key = { it.id }) { app ->
                        AppRow(app, vm) { onOpen(app) }
                    }
                }
            }
        }
    }
}

@Composable
fun AppRow(app: StoreApp, vm: StoreViewModel, onClick: () -> Unit) {
    val context = LocalContext.current
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AppIcon(app, 56.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(app.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "v${app.versionName} · ${Formatter.formatShortFileSize(context, app.sizeBytes)}",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        Spacer(Modifier.width(8.dp))
        ActionButton(app, vm)
    }
}

@Composable
fun DetailScreen(app: StoreApp, vm: StoreViewModel) {
    val context = LocalContext.current
    val p = vm.progress[app.id]
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AppIcon(app, 80.dp)
            Spacer(Modifier.width(16.dp))
            Column {
                Text(app.name, style = MaterialTheme.typography.headlineSmall)
                Text(app.packageName, style = MaterialTheme.typography.bodySmall)
            }
        }
        Spacer(Modifier.height(16.dp))
        Text(
            "Version ${app.versionName} · ${Formatter.formatShortFileSize(context, app.sizeBytes)} · ${app.downloads} downloads",
            style = MaterialTheme.typography.bodyMedium,
        )
        Spacer(Modifier.height(16.dp))
        ActionButton(app, vm)
        if (p != null) {
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { p }, modifier = Modifier.fillMaxWidth())
        }
        Spacer(Modifier.height(24.dp))
        Text(app.description.ifBlank { "No description." })
    }
}

@Composable
fun ActionButton(app: StoreApp, vm: StoreViewModel) {
    val context = LocalContext.current
    val p = vm.progress[app.id]
    val installedCode = vm.installed[app.packageName]

    if (p != null) {
        OutlinedButton(onClick = { vm.cancel(app) }) { Text("${(p * 100).toInt()}%  ✕") }
    } else if (installedCode == null) {
        Button(onClick = { vm.install(app) }) { Text("Install") }
    } else if (installedCode < app.versionCode) {
        Button(onClick = { vm.install(app) }) { Text("Update") }
    } else {
        OutlinedButton(onClick = { Installer.open(context, app.packageName) }) { Text("Open") }
    }
}

@Composable
fun AppIcon(app: StoreApp, size: Dp) {
    val shape = RoundedCornerShape(size / 4)
    if (app.iconUrl != null) {
        AsyncImage(
            model = app.iconUrl,
            contentDescription = app.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(size).clip(shape),
        )
    } else {
        Box(
            Modifier.size(size).clip(shape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Text(app.name.take(1).uppercase(), style = MaterialTheme.typography.titleLarge)
        }
    }
}
