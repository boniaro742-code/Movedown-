package com.movedown.store

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.movedown.store.data.Api
import com.movedown.store.data.StoreApp
import com.movedown.store.install.Installer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

sealed interface UiState {
    data object Loading : UiState
    data class Error(val message: String) : UiState
    data class Ready(val apps: List<StoreApp>) : UiState
}

class StoreViewModel(application: Application) : AndroidViewModel(application) {

    var state by mutableStateOf<UiState>(UiState.Loading)
        private set

    var query by mutableStateOf("")
        private set

    /** appId -> download progress (0f..1f) for apps currently downloading. */
    var progress by mutableStateOf<Map<String, Float>>(emptyMap())
        private set

    /** packageName -> installed versionCode. */
    var installed by mutableStateOf<Map<String, Long>>(emptyMap())
        private set

    var message by mutableStateOf<String?>(null)

    private val jobs = mutableMapOf<String, Job>()
    private var loadJob: Job? = null

    init {
        load()
    }

    fun load(debounceMs: Long = 0) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            if (debounceMs > 0) delay(debounceMs)
            if (state !is UiState.Ready) state = UiState.Loading
            try {
                val apps = Api.listApps(query)
                state = UiState.Ready(apps)
                refreshInstalled()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                state = UiState.Error(e.message ?: "Network error")
            }
        }
    }

    fun onQueryChange(value: String) {
        query = value
        load(debounceMs = 300)
    }

    fun refreshInstalled() {
        val apps = (state as? UiState.Ready)?.apps ?: return
        val context = getApplication<Application>()
        installed = apps.mapNotNull { app ->
            Installer.installedVersionCode(context, app.packageName)?.let { app.packageName to it }
        }.toMap()
    }

    fun install(app: StoreApp) {
        val context = getApplication<Application>()
        if (!Installer.canInstall(context)) {
            message = "Allow MoveDown to install apps, then tap Install again"
            Installer.openInstallSettings(context)
            return
        }
        if (jobs[app.id]?.isActive == true) return

        jobs[app.id] = viewModelScope.launch {
            progress = progress + (app.id to 0f)
            val file = File(context.cacheDir, "apks/${app.packageName}.apk")
            try {
                file.delete()
                Api.download(app.downloadUrl, file) { p -> progress = progress + (app.id to p) }
                Installer.install(context, file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "Download failed: ${e.message ?: "unknown error"}"
            } finally {
                progress = progress - app.id
            }
        }
    }

    fun cancel(app: StoreApp) {
        jobs[app.id]?.cancel()
    }
}
