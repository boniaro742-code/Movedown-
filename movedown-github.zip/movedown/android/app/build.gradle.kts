plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.movedown.store"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.movedown.store"
        minSdk = 24
        targetSdk = 35
        // CI (GitHub Actions) sets VERSION_CODE / VERSION_NAME; locally the defaults are used.
        versionCode = System.getenv("VERSION_CODE")?.toIntOrNull() ?: 1
        versionName = System.getenv("VERSION_NAME") ?: "1.0.0"

        // >>> Your Cloudflare Worker URL (keep the trailing slash).
        // On GitHub: Settings > Secrets and variables > Actions > Variables > BASE_URL
        // Locally: change the fallback below.
        val baseUrl = System.getenv("BASE_URL")?.takeIf { it.isNotBlank() } ?: "https://movedown.YOUR-NAME.workers.dev/"
        buildConfigField("String", "BASE_URL", "\"$baseUrl\"")
    }

    // Release signing – only active when the keystore env vars exist (GitHub secrets).
    val keystorePath = System.getenv("KEYSTORE_FILE")
    signingConfigs {
        if (keystorePath != null) {
            create("release") {
                storeFile = file(keystorePath)
                storePassword = System.getenv("KEYSTORE_PASSWORD")
                keyAlias = System.getenv("KEY_ALIAS")
                keyPassword = System.getenv("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            manifestPlaceholders["usesCleartext"] = "true"   // lets you test with http:// locally
        }
        release {
            isMinifyEnabled = false
            manifestPlaceholders["usesCleartext"] = "false"  // production must use https://
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            if (keystorePath != null) signingConfig = signingConfigs.getByName("release")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("io.coil-kt:coil-compose:2.7.0")
}
